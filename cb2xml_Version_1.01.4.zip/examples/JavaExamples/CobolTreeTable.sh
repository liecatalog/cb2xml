#! /bin/sh

##
##  Display a Cobol Copybook as a "Tree-Table"
##
java -cp ../../lib/cb2xml.jar:../../lib/cb2xml_Jaxb.jar:./cb2xml_example.jar net.sf.cb2xml.example.DemoCobolJTreeTable cbl2xml_Test102.cbl
 