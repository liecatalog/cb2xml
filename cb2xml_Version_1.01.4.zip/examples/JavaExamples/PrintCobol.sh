#! /bin/sh

##
##  Print the copybook details to the terminal
##
java -cp ../../lib/cb2xml.jar:../../lib/cb2xml_Jaxb.jar:./cb2xml_example.jar net.sf.cb2xml.example.Demo2 cbl2xml_Test102.cbl
