
/**
 * This package holds classes to parse cobol and cb2xml - Xml into
 * Java classes
 * 
 * @author Bruce Martin
 *
 */
package net.sf.cb2xml.parse;