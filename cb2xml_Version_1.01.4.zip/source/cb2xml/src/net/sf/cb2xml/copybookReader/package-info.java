/**
 * This package holds classes to read / pre-process Cobol copybooks
 */
package net.sf.cb2xml.copybookReader;